package com.frontend.userservice.service;

import com.frontend.userservice.dto.RestResponsePage;
import com.frontend.userservice.dto.UserRequestDTO;
import com.frontend.userservice.dto.UserResponseDTO;
import com.frontend.config.JwtInterceptor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.List;

@Service
public class FrontendUserService {

    private final RestClient restClient;
    private final JwtInterceptor jwtInterceptor;

    @Value("${backend.url:http://localhost:8080}")
    private String backendUrl;

    public FrontendUserService(JwtInterceptor jwtInterceptor) {
        this.jwtInterceptor = jwtInterceptor;
        this.restClient = RestClient.create();
    }

    // ================= USERS =================

    public Page<UserResponseDTO> getAllUsers(int page, int size) {
        String url = backendUrl + "/api/users?page=" + page + "&size=" + size;

        return jwtInterceptor.addAuthHeader(
                restClient.get().uri(url)
        ).retrieve().body(new ParameterizedTypeReference<RestResponsePage<UserResponseDTO>>() {});
    }

    public List<String> getAllRoles() {
        String url = backendUrl + "/api/roles";

        return jwtInterceptor.addAuthHeader(
                restClient.get().uri(url)
        ).retrieve().body(new ParameterizedTypeReference<List<String>>() {});
    }

    public void createUser(UserRequestDTO dto) {
        String url = backendUrl + "/api/users";

        jwtInterceptor.addAuthHeader(
                restClient.post().uri(url).body(dto)
        ).retrieve().toBodilessEntity();
    }

    public UserResponseDTO getUserById(Integer id) {
        String url = backendUrl + "/api/users/" + id;

        return jwtInterceptor.addAuthHeader(
                restClient.get().uri(url)
        ).retrieve().body(UserResponseDTO.class);
    }

    public void updateUser(Integer id, UserRequestDTO dto) {
        String url = backendUrl + "/api/users/" + id;

        jwtInterceptor.addAuthHeader(
                restClient.put().uri(url).body(dto)
        ).retrieve().toBodilessEntity();
    }

    public void deleteUser(Integer id) {
        String url = backendUrl + "/api/users/" + id;

        jwtInterceptor.addAuthHeader(
                restClient.delete().uri(url)
        ).retrieve().toBodilessEntity();
    }

    // ================= SEARCH =================

    public Page<UserResponseDTO> searchUsers(String username, int page, int size) {
        String url = backendUrl + "/api/users/search?username=" + username + "&page=" + page + "&size=" + size;

        return jwtInterceptor.addAuthHeader(
                restClient.get().uri(url)
        ).retrieve().body(new ParameterizedTypeReference<RestResponsePage<UserResponseDTO>>() {});
    }

    public Page<UserResponseDTO> getUsersByRole(String role, int page, int size) {
        String url = backendUrl + "/api/users/role?role=" + role + "&page=" + page + "&size=" + size;

        return jwtInterceptor.addAuthHeader(
                restClient.get().uri(url)
        ).retrieve().body(new ParameterizedTypeReference<RestResponsePage<UserResponseDTO>>() {});
    }

    // ================= ROLES =================

    public List<String> getUserRoles(Integer id) {
        String url = backendUrl + "/api/users/" + id + "/roles";

        return jwtInterceptor.addAuthHeader(
                restClient.get().uri(url)
        ).retrieve().body(new ParameterizedTypeReference<List<String>>() {});
    }

    public void assignRolesToUser(Integer id, List<String> roles) {
        String url = backendUrl + "/api/users/" + id + "/roles";

        jwtInterceptor.addAuthHeader(
                restClient.post().uri(url).body(roles)
        ).retrieve().toBodilessEntity();
    }

    // ================= PROFILE =================

    public UserResponseDTO getCurrentUser() {
        String url = backendUrl + "/api/users/me";

        return jwtInterceptor.addAuthHeader(
                restClient.get().uri(url)
        ).retrieve().body(UserResponseDTO.class);
    }

    public void updateCurrentUser(UserRequestDTO dto) {
        String url = backendUrl + "/api/users/me";

        jwtInterceptor.addAuthHeader(
                restClient.put().uri(url).body(dto)
        ).retrieve().toBodilessEntity();
    }
}