package com.frontend.taskservice.service;

import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClient;

import com.frontend.taskservice.dto.TaskDTO;

@Service
public class TaskService {
	

    private final RestClient restClient =
            RestClient.builder()
                    .baseUrl("http://localhost:8080")
                    .build();
    
    public List<TaskDTO> getAllTasks() {
        return restClient.get()
                .uri("/api/tasks/all")
                .retrieve()
                .body(new ParameterizedTypeReference<List<TaskDTO>>() {});
    }

    // ✅ CREATE — Content-Type must be set so backend @RequestBody parses correctly
    public TaskDTO createTask(TaskDTO task) {

        try {
            return restClient.post()
                    .uri("/api/tasks/create")
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(task)
                    .retrieve()
                    .body(TaskDTO.class);

        } catch (Exception e) {
            e.printStackTrace(); // 🔥 THIS WILL SHOW REAL ERROR
            throw e;
        }
    }

    

    // ✅ GET BY ID
    public TaskDTO getTaskById(Integer id) {
       try {
    	   return restClient.get()
                .uri("/api/tasks/{id}", id)
                .retrieve()
                .body(TaskDTO.class);
    } catch (HttpStatusCodeException ex) {

        // 🔥 Extract message from backend
        String response = ex.getResponseBodyAsString();

        throw new RuntimeException(response);
    }
}

  
    public TaskDTO updateTask(Integer id, TaskDTO task) {
        return restClient.put()
                .uri("/api/tasks/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .body(task)
                .retrieve()
                .body(TaskDTO.class);
    }

    // ✅ SEARCH
    public List<TaskDTO> searchTasks(String name) {
        return restClient.get()
                .uri("/api/tasks/search/{name}", name)
                .retrieve()
                .body(new ParameterizedTypeReference<List<TaskDTO>>() {});
    }
    public List<TaskDTO> searchByStatus(String status) {
        return restClient.get()
                .uri("/api/tasks/status/{status}", status)
                .retrieve()
                .body(new ParameterizedTypeReference<List<TaskDTO>>() {});
    }

    public List<TaskDTO> searchByPriority(String priority) {
        return restClient.get()
                .uri("/api/tasks/priority/{priority}", priority)
                .retrieve()
                .body(new ParameterizedTypeReference<List<TaskDTO>>() {});
    }
    public List<TaskDTO> getByProject(Integer projectId) {
        return restClient.get()
                .uri("/api/tasks/project/{projectId}", projectId)
                .retrieve()
                .body(new ParameterizedTypeReference<List<TaskDTO>>() {});
    }
    public List<TaskDTO> getByUser(Integer userId) {
        return restClient.get()
                .uri("/api/tasks/user/{userId}", userId)
                .retrieve()
                .body(new ParameterizedTypeReference<List<TaskDTO>>() {});
    }
    public List<TaskDTO> filterTasks(String status, String priority) {
       
            return restClient.get()
                    .uri("/api/tasks/filter?status=" + status + "&priority=" + priority)
                    .retrieve()
                    .body(new ParameterizedTypeReference<List<TaskDTO>>() {});
        
    }
    public Long countTasksByStatus(String status) {
        
            return restClient.get()
                    .uri("/api/tasks/count/" + status)
                    .retrieve()
                    .body(Long.class);
        }
    }
    
    